README FILE: This read me file contains 2 sections
<1> Descrpition: It goes over how to compile and run with a simple description for each question.
<2> Sample Runtime: An estimate runtime for MyCompress (sequential), ParFork (Multi-Fork), and ParThread (Multi-Thread) for 3 different sizes of file as required for #10

<1>:

1) My Compress: 
To Run: g++ -o MyCompress MyCompress.cpp
./MyCompress source.txt destination.txt

Takes in a binary text file, with 0's or 1's separated only by a space, or a new line and compresses with '+' for 1's and '-' for 0's with a number indicating how many 0's or 1's there are, then outputs to a new file indicated with command line arguments 

2) My Decompress:
To Run: g++ -o MyDecompress MyDecompress.cpp
./MyDecompress source.txt destionation.txt

Takes in an already compressed binary text file, with 0's, 1's and numbers representing lengths of 1's or 0's which is also represented by a '-' or '+', and outputs a decompressed version using command line arguments for file destinations.

3) Fork Compress:
To Run: g++ -o ForkCompress ForkCompress.cpp
./ForkCompress source.txt destination.txt

Takes in a binary text file, as well as an output file destination, and compresses by forking and running an execl with MyCompress in the child process using the command line arguments for file destinations.

ForkCompress.cpp must be in the same directory as MyCompress.cpp

4) Pipe Compress:
Compile with g++ -o PipeCompress PipeCompress.cpp
run it with the format ./PipeCompress source_file output_file

Pipe compress does the exact same thing as MyCompress but it use pipe to read and write the file instead of handling the whole file at once

5) ParFork:
Compile with g++ -o ParFork ParFork.cpp
run it with the format ./ParFork source_file output_file

ParFork divide the file into several parts and create multiple child processes to handle the compression to reduce the workload 

6)Mini Shell:
Compile with g++ -o MiniShell MiniShell.cpp
run it with ./MiniShell

Mini Shell takes one single input (not a line) and execute the command prompt command by using execlp

7) More Shell:
Compile with g++ -o MoreShell MoreShell.cpp
run it with ./MoreShell

More Shell takes a line of user input and separated them into a list of argument and execute it, once it executed it will return back to the shell until the user type in "exit"

8) Dup Shell:
Compile with g++ -o DupShell DupShell.cpp
run it with ./DupShell

Same as More Shell but take extra command after "|"

9) ParThread:
Compile with g++ -o ParThread ParThread.cpp -lpthread
runt it with ./ParThread source_file output_file

ParThread takes a source file, count the number of line separated with " " and return, then divide it up to multiple threads to compress the input file then write it to the output file.

<2>:
The programs were tested in three different sizes of file (round it down): 100 B 2 KB 7 MB

1) MyCompress:
source file 1 (100 bytes) est 0.00344491s 
source file 2 (2kbs) est 0.00292961s 
source file 3 (7 MBs) est 0.548469s 

2) ParFork:
source file 1 (100 bytes) It took: 0.00380132s to finish.
source file 2 (2kbs) It took: 0.00442104s to finish.
source file 3 (7 MBs) It took: 0.184006s to finish.

3) ParThread:
source file 1 (100 bytes): est. 0.00328992 s
source file 2 (2 kbs): est 0.0113488 s
source file 3 (7 MBs): est 0.277384 s
