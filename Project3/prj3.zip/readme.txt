This readme text file will include the description and the running configuration for project3.

Problem 1 (Reverse String using threads)
Compile: g++ -o srv Server.cpp -lpthread && g++ -o client Client.cpp
To Run(first need to run server): ./srv
Then run: ./client

client will prompt user to enter a string which will send to the server. 
The server will then reverse the string and send back to the client.  
The client will output the servers message.  
Multiple clients can be run at the same time.

Problem 2 (exec with ls command using fork)
Compile: g++ -o serverExec ServerExec.cpp && g++ -o clientExec ClientExec.cpp
To Run(first need to run server): ./serverExec
Then run: ./clientExec

client will prompt user to enter a command used for ls such as -l. 
The server will then fork the process.  
The child process will use execvp
and will redirect the output to a file named t.txt 
which will be read in the parent process in order to send back to the client.  
The client will output the servers message.

Problem 3
Compile :g++ -o diskS disk_server.cpp -lpthread
Run :./diskS

Server receive user's command and using if-else statements to response

Compile : g++ -o diskC disk_client.cpp
Run :./diskC
(a) Command-line driven client :
Work in a while loop, having the user type in the command, send the command to the server, and display
the result to the user.
Command accept : (c = value of cylinder's size, s = value of sector's size)
C c s : a command use to create a c * s virtual disk file
D : a command use to delete a virtual disk file
I : a command use to view the size of the virtual disk file
R c s : a command use to read a specific location of virtual disk file
W c s l: a command use to write l (a string with length that less than 129 bytes) in a specific location of virtual disk file
exit : a commmand use to exit the system.

Compile : g++ -o diskR random_data_client.cpp
Run :./diskR
(b) Random data client :
Work in a while loop, having the user type in the command, send the command to the server, and display
the result to the user.
Command accept : 
I : a command use to view the size of the virtual disk file
N : type in any number, the server will generate equal amount of random read/write request,
after the server finished, it will send back a sentence like Seed: 1 0 .... , which a character representing each request is sufficent 
exit : a commmand use to exit the system.


Problem 4 and 5
Compile:
1) g++ -o fs_server fs_server.cpp -lpthread
2) g++ -o fs_client fs_client.cpp

To Run:
1) ./fs_server (to start up the server)
2) ./fs_client

Problem 4 and 5 are related together so the server and client will be able to respond to both problem 4 and problem 5's requirement.
This is a simulation of a simple file system where a virtual file system is created as a .txt file which allows the user
to create a simple .txt extention file and as many directories as they want with the function listed below to manage
this virtual file system.
-
The client will prompt the user to enter a command which list in a menu when the user first run it.
Once the user enter a command, the server will process the command and return the result to the user.

The Command list is listed below with example input:
[F]: format/initialize the file system. ex) F
[RESET]: remove the current existing file system, and user can re-create by using [F]. ex) RESET
[C filename]: create a .txt extention file where user can read and write with later on. ex) C test.txt (.txt must be included)
[D filename]: delete a current existed .txt extention file in the current directory. ex) delete test.txt
[L 0/1]: List all the files/directories under the current directory. 0 shows less detail, 1 shows advance detail with the real format of the file. ex) L 0
[R filename]: read an existing .txt file under the current directory. ex) R test.txt
[W filename data]: write to an existing .txt file under the current directory with specific data (one line of input without space, _ is avaliable to replace space). ex) W test.txt hello_world!
[mkdir directory_name]: create a new directory under the current directory. ex) mkdir test (no need for extension)
[cd directory_name]: change the current directory to an exisiting directory under the current directory. ex) cd test
(cd .. will return to the previous directory/ cd ... will return back to the root directory)
[pwd]: print the workign directory
[rmdir directory_name]: remove an existing directory under the current directory. ex) rmdir test 

limitation:
- This virtual file system's client can receive only upto 32768 (2^15) characters message at once as return. This can be changed through the configuration
- As mentioned in the W function, the virtual .txt file cannot include a space, but it can use "_" as replacement.
- The file configuration contains the character "&", "|" and "~" which users are not allowed to use this 3 special characters (if they used, it will result in error or integrity issue of the file system)