The zip file contains all the following elements:
-question sample code
-question command prompt executable file (compiled through UNIX based system)
-script program sample code (except question 1)
-script program command prompt executable file (compiled through UNIX based system)

Below are the description and design for each question.

#1:
Producer Consumer is to implement the producer consumer from the lecture note by using thread handling technique to
make the program work in the way of protecting critical resource.

To Run: 
1) g++ -o bufferpc bufferpc.cpp -lpthread
2) ./bufferpc

#2:
Mother Hubbard:
To Run: g++ -o MH Mother_Hubbard.cpp -lpthread
Use Value N (N >= 0)
./MH N 

Takes In a Value N representing how many days(iterations) and displays Parents Following Steps In order to 
take care of 12 children. Uses pthreads to split work up so both parents can work in parallel. 
#3:
Question 3 is asking to design an airport simulation multi-threads program which take i passengers,
j baggage handlers, k security scanners, and l flight attendants through command line argument.
To Run: 
1) g++ -o airline airline.cpp -lpthread
2) ./airline (# of passengers) (# of baggage handlers) (# of security scanners) (# of flight attendants)